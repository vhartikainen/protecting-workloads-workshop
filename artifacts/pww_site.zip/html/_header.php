<?php
// get template and replace placeholders
$template .= file_get_contents('includes/header.html');
